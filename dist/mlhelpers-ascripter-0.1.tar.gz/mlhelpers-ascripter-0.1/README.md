# mlhelpers package

Introducing ``DataFrameModier`` class as link between ``pandas.DataFrame``
and models from ``sklearn`` oder ``statsmodels``
